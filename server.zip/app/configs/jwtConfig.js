module.exports = {
    secret: 'cashie-key'
}