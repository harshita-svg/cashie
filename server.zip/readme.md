/********************** ReadMe.md ***************************/

To Start this project you will need to follow the instructions given Below : 

1- Remove .example from the .env.example file name. It should look something like this : .env
2- Create a your account on MongoDB Atlas and copy your db connection url and paste it into the .env file in front of MONGO_URI variable. You can paste it without using any Quotes("", '').

3- Then Open the terminal of your IDE , i.e; VS Code. Make sure that you are in the project directory. 

4- Then run the following command in terminal : npm install
5- After that command finished successfully. Run the next command in the same terminal : npm start.

If You have followed all of the above steps correctly , then your backend should be up and running successfully.

!!!!!!!!!!!!!!!!!CONGRATS!!!!!!!!!!!!!!!!!!!!!!!!